(function(){const zt=/(?<![0-9a-fA-Fx])0x[a-fA-F0-9]{40}(?![0-9a-fA-F])/g,Dt=/(?<![A-Za-z0-9$])\$([A-Za-z]{1,6})(?![A-Za-z0-9])/g,gt={AAPL:"0xaF3D76f1834A1d425780943C99Ea8A608f8a93f9",TSLA:"0x322F0929c4625eD5bAd873c95208D54E1c003b2d",NVDA:"0xd0601CE157Db5bdC3162BbaC2a2C8aF5320D9EEC",MSFT:"0xe93237C50D904957Cf27E7B1133b510C669c2e74",GOOGL:"0x2e0847E8910a9732eB3fb1bb4b70a580ADAD4FE3",AMZN:"0x12f190a9F9d7D37a250758b26824B97CE941bF54",META:"0xc0D6457C16Cc70d6790Dd43521C899C87ce02f35",SPY:"0x117cc2133c37B721F49dE2A7a74833232B3B4C0C"},Bt=new Set(["USD","USDC","USDT","USDG","DAI","FDUSD","TUSD","PYUSD","USDE","EUR","GBP","JPY","CNY","INR","BTC","ETH","WETH","WBTC","BNB","SOL","XRP"]),xt="data-strix-scanned",It="data-strix-host",Ut=["0.01","0.05","0.1","0.25"],Pt=[25,50,100],w=t=>new Promise(e=>{try{chrome.runtime.sendMessage(t,o=>{chrome.runtime.lastError?e({error:chrome.runtime.lastError.message}):e(o||{})})}catch(o){e({error:String(o)})}}),dt=t=>{const e=Number(t);if(!isFinite(e)||t==null)return"-";if(e===0)return"$0";const o=Math.abs(e);if(o>=1)return"$"+e.toLocaleString(void 0,{maximumFractionDigits:2});if(o>=.01)return"$"+e.toFixed(4);const n=Math.min(14,Math.ceil(-Math.log10(o))+2);return"$"+e.toFixed(n).replace(/0+$/,"").replace(/\.$/,"")},rt=t=>{const e=Number(t);return!isFinite(e)||t==null?"-":"$"+Intl.NumberFormat(void 0,{notation:"compact",maximumFractionDigits:2}).format(e)},Ot=t=>{const e=Number(t);return isFinite(e)?e.toLocaleString(void 0,{maximumFractionDigits:e<1?6:4}):"0"},st=t=>`${t.slice(0,6)}…${t.slice(-4)}`,S=t=>(t||"").replace(/[<>&"]/g,e=>({"<":"&lt;",">":"&gt;","&":"&amp;",'"':"&quot;"})[e]||e),kt=`<img src="${chrome.runtime.getURL("icons/icon48.png")}" width="16" height="16" style="border-radius:4px;display:block" alt=""/>`,Xt='<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 4v3"/><rect x="7" y="7" width="4" height="9" rx="1"/><path d="M9 16v3"/><path d="M17 2v4"/><rect x="15" y="6" width="4" height="7" rx="1"/><path d="M17 13v4"/></svg>',it='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>',Kt='<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',jt='<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="9" r="4.5"/><circle cx="17" cy="7" r="2.5"/><circle cx="15.5" cy="16.5" r="3.5"/><path d="M11.5 11.8 13 14"/><path d="M12.3 8.2 14.6 7.6"/></svg>',v=(t,e)=>{for(const o of e){const n=o.split(".").reduce((c,g)=>c?.[g],t);if(n!=null&&n!=="")return n}},ot=t=>{if(t==null||t==="")return;if(typeof t=="boolean")return t;const e=String(t).toLowerCase();return["1","yes","true"].includes(e)?!0:["0","no","false"].includes(e)?!1:void 0},at=t=>{const e=Number(t);if(!(!isFinite(e)||t===void 0||t===null||t===""))return e<=1?e*100:e};function ht(t){const e=ot(v(t,["is_honeypot","honeypot"])),o=at(v(t,["buy_tax"])),n=at(v(t,["sell_tax"])),c=ot(v(t,["is_open_source","open_source","verified"])),g=ot(v(t,["is_renounced","renounced","owner_renounced"])),r=ot(v(t,["lock_summary.is_locked","is_locked","locked"])),u=at(v(t,["lock_summary.lock_percent","lock_percent"])),d=at(v(t,["top_10_holder_rate","top10_holder_rate"])),s=v(t,["rug_ratio"]),l=Number(s),h=x=>x==null?"?":`${x.toFixed(x<10?1:0)}%`,M=[...e===!0?[{label:"Honeypot",value:"YES — can't sell",level:"bad"}]:[],{label:"Buy tax",value:h(o),level:o==null?"na":o>10?"bad":o>3?"warn":"ok"},{label:"Sell tax",value:h(n),level:n==null?"na":n>10?"bad":n>3?"warn":"ok"},{label:"Verified",value:c==null?"Unknown":c?"Yes":"No",level:c==null?"na":c?"ok":"warn"},{label:"Renounced",value:g==null?"Unknown":g?"Yes":"No",level:g==null?"na":g?"ok":"warn"}];r!=null&&M.push({label:"Liq. locked",value:r?u!=null?`Yes (${u.toFixed(0)}%)`:"Yes":"No",level:r?"ok":"warn"}),d!=null&&M.push({label:"Top 10 hold",value:`${d.toFixed(1)}%`,level:d>50?"bad":d>30?"warn":"ok"}),s!=null&&isFinite(l)&&M.push({label:"Rug risk",value:`${(l<=1?l*100:l).toFixed(0)}%`,level:l>.3?"bad":l>.1?"warn":"ok"});const T=M.some(x=>x.level==="bad")?"bad":M.some(x=>x.level==="warn")?"warn":"ok";return{checks:M,verdict:T}}const mt={ok:"No red flags",warn:"Caution",bad:"High risk"},Gt=t=>Array.isArray(t)?t:t?.list||t?.holders||t?.traders||[],Yt=t=>!!t?.exchange||t?.addr_type===2,ct=t=>{const e=[];for(const o of["tags","maker_token_tags"]){const n=t?.[o];if(Array.isArray(n))for(const c of n)c&&!e.includes(String(c))&&e.push(String(c))}return e},lt={kol:{label:"KOL",cls:"kol"},renowned:{label:"KOL",cls:"kol"},smart_degen:{label:"Smart $",cls:"smart"},whale:{label:"Whale",cls:"mut"},dev:{label:"Dev",cls:"bad"},creator:{label:"Dev",cls:"bad"},rat_trader:{label:"Insider",cls:"bad"},wash_trader:{label:"Wash",cls:"bad"},sniper:{label:"Sniper",cls:"mut"},bundler:{label:"Bundler",cls:"mut"},fresh_wallet:{label:"Fresh",cls:"mut"}};function qt(t){if(!t)return[];const e=v(t,["link","links","social_links"])||t,o=[],n=v(e,["website","official_website"]);n&&o.push({label:"Web",url:String(n)});const c=v(e,["twitter_username","twitter"]);c&&o.push({label:"𝕏",url:String(c).startsWith("http")?String(c):`https://x.com/${String(c).replace(/^@/,"")}`});const g=v(e,["telegram"]);g&&o.push({label:"Telegram",url:String(g).startsWith("http")?String(g):`https://t.me/${String(g).replace(/^@/,"")}`});const r=v(e,["discord"]);return r&&String(r).startsWith("http")&&o.push({label:"Discord",url:String(r)}),o.filter(u=>/^https?:\/\//.test(u.url)).slice(0,4)}function Wt(t,e){const o=String(v(t,["wallet_address","address","account_address"])||""),n=Yt(t),c=n?[]:ct(t),g=n?`${String(t.exchange||"DEX").replace(/_/g," ")} pool`:v(t,["name","twitter_username","twitter_name"]),r=Number(v(t,["amount_percentage"])),u=isFinite(r)&&r>0?`${(r<=1?r*100:r).toFixed(2)}%`:"",d=Number(v(t,["sell_amount_percentage"])),s=!n&&isFinite(d)&&d>0?`sold ${Math.min(100,d<=1?d*100:d).toFixed(0)}%`:"",l=n?NaN:Number(v(t,["profit","realized_profit"])),h=isFinite(l)&&l!==0?`<span class="p ${l>=0?"up2":"dn2"}">${l>=0?"+":"-"}${dt(Math.abs(l)).replace("$","$")}</span>`:"",M=(n?'<span class="htag mut">Pool</span>':"")+c.filter(x=>lt[x]).slice(0,3).map(x=>`<span class="htag ${lt[x].cls}">${lt[x].label}</span>`).join(""),T=g?S(String(g)):`${o.slice(0,6)}…${o.slice(-4)}`;return`<div class="hrow">
    <span class="hrank">${e}</span>
    <div class="hmain">
      <a class="haddr" href="https://robinhoodchain.blockscout.com/address/${S(o)}" target="_blank" rel="noreferrer" title="${S(o)}">${T}</a>${M}
      <div class="hsub">${[u?u+" supply":"",s].filter(Boolean).join(" · ")}</div>
    </div>
    <div class="hval">${h}</div>
  </div>`}const vt=t=>{if(!isFinite(t))return"";const e=Math.abs(t);if(e>=1e6)return"$"+(t/1e6).toFixed(2)+"M";if(e>=1e3)return"$"+(t/1e3).toFixed(2)+"K";if(e>=1)return"$"+t.toFixed(2);if(e>=.01)return"$"+t.toFixed(4);const o=Math.min(12,Math.ceil(-Math.log10(e))+2);return"$"+t.toFixed(o).replace(/0+$/,"")};function Vt(t,e){let l=1/0,h=-1/0;for(const b of t)b[3]<l&&(l=b[3]),b[2]>h&&(h=b[2]);if(!isFinite(l)||!isFinite(h)||h<=0)return"";const M=(h-l)*.06||h*.02;l-=M,h+=M;const T=b=>230-(b-l)/(h-l)*218,x=t.length,B=342/x,y=Math.max(1.5,Math.min(9,B*.62));let E="";for(let b=0;b<=3;b++){const F=l+(h-l)*b/3,C=T(F).toFixed(1);E+=`<line x1="8" y1="${C}" x2="350" y2="${C}" stroke="#1e2f24" stroke-dasharray="3 4"/>`,E+=`<text x="356" y="${Number(C)+3}" fill="#9cb490" font-size="9" font-family="Sora,system-ui,sans-serif">${vt(F)}</text>`}const O=b=>{const F=new Date(b*1e3);return e==="15m"||e==="1H"?`${String(F.getHours()).padStart(2,"0")}:${String(F.getMinutes()).padStart(2,"0")}`:F.toLocaleDateString(void 0,{month:"short",day:"numeric"})};for(const b of[.08,.5,.92]){const F=Math.min(x-1,Math.floor(b*x)),C=(8+F*B+B/2).toFixed(1);E+=`<text x="${C}" y="244" fill="#9cb490" font-size="9" text-anchor="middle" font-family="Sora,system-ui,sans-serif">${O(t[F][0])}</text>`}for(let b=0;b<x;b++){const[,F,C,H,L]=t[b],z=8+b*B+B/2,I=L>=F?"#59e08a":"#ff7a7a",U=T(F),A=T(L),K=Math.min(U,A),nt=Math.max(1,Math.abs(U-A));E+=`<line x1="${z.toFixed(1)}" y1="${T(C).toFixed(1)}" x2="${z.toFixed(1)}" y2="${T(H).toFixed(1)}" stroke="${I}"/>`,E+=`<rect x="${(z-y/2).toFixed(1)}" y="${K.toFixed(1)}" width="${y.toFixed(1)}" height="${nt.toFixed(1)}" fill="${I}" rx="0.5"/>`}const X=t[x-1][4],R=T(X);return E+=`<line x1="8" y1="${R.toFixed(1)}" x2="350" y2="${R.toFixed(1)}" stroke="#bff45f" stroke-dasharray="2 3" opacity="0.85"/>`,E+=`<rect x="351" y="${(R-8).toFixed(1)}" width="54" height="15" rx="4" fill="rgba(163,230,53,.15)" stroke="rgba(163,230,53,.4)"/>`,E+=`<text x="${351+54/2}" y="${(R+3.5).toFixed(1)}" fill="#bff45f" font-size="9" font-weight="700" text-anchor="middle" font-family="Sora,system-ui,sans-serif">${vt(X)}</text>`,`<svg viewBox="0 0 408 250" width="100%" style="display:block">${E}</svg>`}const Zt=`
  :host{ all:initial; }
  *{ box-sizing:border-box; font-family:"Sora","Inter",-apple-system,"Segoe UI",Arial,sans-serif; }
  .pill{display:inline-flex;align-items:center;gap:6px;margin-top:8px;padding:7px 13px;border-radius:999px;
    background:linear-gradient(180deg,#b6f24a,#96d92e);border:1px solid #8fd41f;color:#0b140c;font-weight:800;
    font-size:12px;line-height:1;cursor:pointer;transition:.15s;box-shadow:0 5px 16px -6px rgba(120,190,20,.6)}
  .pill:hover{filter:brightness(1.05);transform:translateY(-1px)}
  .pill svg{opacity:.9}
  .panel{margin-top:9px;width:100%;max-width:436px;border-radius:18px;overflow:hidden;color:#eafbe1;
    background:linear-gradient(180deg,#101c13,#0a110c);border:1px solid #223528;
    box-shadow:0 18px 48px -18px rgba(0,0,0,.75), inset 0 1px 0 rgba(255,255,255,.035), 0 0 0 1px rgba(163,230,53,.05);
    animation:rise .22s cubic-bezier(.22,1,.36,1) both}
  @keyframes rise{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
  .badge.stk{color:#8fd0ff;background:rgba(93,169,255,.12);border-color:rgba(93,169,255,.32)}
  .stockline{margin:0 14px 12px;background:#111d15;border:1px solid #1e2f24;border-radius:12px;padding:9px 11px;
    font-size:11.5px;color:#bdd3b2;text-align:center}
  .stockline b{color:#eafbe1}
  .head{display:flex;align-items:center;gap:11px;padding:14px 14px 12px}
  .logo{width:42px;height:42px;border-radius:13px;object-fit:cover;flex:0 0 auto;background:#16241a;
    border:1px solid #2a3f30;display:grid;place-items:center;color:#a3e635}
  .hd{min-width:0;flex:1}
  .symrow{display:flex;align-items:center;gap:6px}
  .sym{font-weight:800;font-size:16px;color:#fff;letter-spacing:-.01em;white-space:nowrap}
  .badge{font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#bff45f;
    background:rgba(163,230,53,.12);border:1px solid rgba(163,230,53,.32);border-radius:6px;padding:2px 5px}
  .name{font-size:11.5px;color:#bdd3b2;margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .carow{margin-top:3px;font-size:9.5px;color:#9cb490;font-family:ui-monospace,monospace;cursor:pointer;width:fit-content}
  .carow:hover{color:#bff45f}
  .carow b{color:#bff45f;font-weight:700}
  .price{text-align:right;flex:0 0 auto}
  .pval{font-weight:800;font-size:16px;color:#fff;display:flex;align-items:center;gap:6px;justify-content:flex-end}
  .live{width:6px;height:6px;border-radius:999px;background:#59e08a;box-shadow:0 0 8px #59e08a;animation:pulse 1.6s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}
  .chg{font-weight:800;font-size:12px;margin-top:3px}
  .up{color:#59e08a} .dn{color:#ff7a7a}
  .stats{display:flex;gap:7px;padding:0 14px 12px}
  .stat{flex:1;background:#111d15;border:1px solid #1e2f24;border-radius:12px;padding:8px 6px;text-align:center}
  .stat span{display:block;font-size:8.5px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#9cb490;margin-bottom:3px}
  .stat b{font-weight:800;font-size:13px;color:#f2fbec}
  .hold{margin:0 14px 11px;background:rgba(163,230,53,.07);border:1px solid rgba(163,230,53,.18);border-radius:12px;
    padding:8px 11px;font-size:12px;color:#bdd3b2}
  .hold b{color:#fff}
  .seg{display:flex;gap:5px;margin:0 14px 10px;background:#111d15;border:1px solid #1e2f24;border-radius:12px;padding:4px}
  .seg button{flex:1;border:0;background:transparent;color:#aec6a3;font-weight:800;font-size:13px;padding:8px 0;
    border-radius:9px;cursor:pointer;transition:.15s}
  .seg button.chartbtn{flex:0 0 48px;display:grid;place-items:center;padding:7px 0}
  .seg button.chartbtn:hover{color:#bff45f}
  .tfrow{display:flex;gap:5px;margin:0 14px 10px;align-items:center}
  .tfbtn{flex:1;padding:6px 0;border-radius:9px;background:#111d15;color:#c3d4ba;border:1px solid #1e2f24;
    font-weight:700;font-size:11.5px;cursor:pointer;transition:.12s}
  .tfbtn:hover{border-color:#31503a;color:#eafbe1}
  .tfbtn.on{background:rgba(163,230,53,.15);border-color:rgba(163,230,53,.5);color:#bff45f}
  .tfchg{flex:0 0 auto;font-size:11.5px;font-weight:800;padding:0 4px}
  .chartbox{margin:0 14px 12px;background:#0d1712;border:1px solid #1e2f24;border-radius:12px;overflow:hidden;min-height:120px}
  .socials{display:flex;gap:12px;margin:-4px 14px 10px;font-size:11px}
  .socials a{color:#aec6a3;text-decoration:none;font-weight:700}
  .socials a:hover{color:#bff45f;text-decoration:underline}
  .secbar{margin:0 14px 11px;display:flex;align-items:center;gap:7px;border-radius:12px;border:1px solid #1e2f24;
    padding:8px 11px;font-size:12px;font-weight:800;cursor:pointer}
  .secbar i{margin-left:auto;font-style:normal;font-weight:600;font-size:10.5px;opacity:.75}
  .secbar.ok{color:#bff45f;border-color:rgba(163,230,53,.35);background:rgba(163,230,53,.07)}
  .secbar.warn{color:#fbbf24;border-color:rgba(251,191,36,.35);background:rgba(251,191,36,.07)}
  .secbar.bad{color:#ff7a7a;border-color:rgba(255,122,122,.4);background:rgba(255,122,122,.08)}
  .secbar.na{color:#aec6a3;background:#111d15;font-weight:600;cursor:pointer}
  .secgrid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:0 14px 10px}
  .seccell{display:flex;justify-content:space-between;gap:6px;background:#111d15;border:1px solid #1e2f24;border-radius:10px;padding:7px 10px;font-size:11px}
  .seccell span{color:#9cb490}
  .seccell b.ok{color:#59e08a}.seccell b.warn{color:#fbbf24}.seccell b.bad{color:#ff7a7a}.seccell b.na{color:#aec6a3}
  .tabs2{display:flex;gap:5px;margin:0 14px 8px;background:#111d15;border:1px solid #1e2f24;border-radius:10px;padding:3px}
  .tabs2 button{flex:1;border:0;background:transparent;color:#aec6a3;font-weight:800;font-size:11.5px;padding:6px 0;border-radius:8px;cursor:pointer}
  .tabs2 button.on{background:#a3e635;color:#0b140c}
  .chips{display:flex;gap:5px;margin:0 14px 9px}
  .chip2{padding:4px 10px;border-radius:8px;background:#111d15;border:1px solid #1e2f24;color:#aec6a3;font-size:10.5px;font-weight:700;cursor:pointer}
  .chip2.on{background:rgba(163,230,53,.15);border-color:rgba(163,230,53,.5);color:#bff45f}
  .kolline{margin:0 14px 8px;font-size:10.5px;color:#aec6a3}
  .kolline b{color:#fbbf24}
  .hrow{display:flex;align-items:center;gap:8px;margin:0 14px 6px;background:#111d15;border:1px solid #1e2f24;border-radius:10px;padding:7px 10px}
  .hrank{width:18px;flex:0 0 auto;text-align:center;color:#9cb490;font-size:10px;font-weight:800}
  .hmain{flex:1;min-width:0}
  .haddr{color:#eafbe1;font-size:11.5px;font-weight:700;text-decoration:none}
  .haddr:hover{color:#bff45f;text-decoration:underline}
  .htag{display:inline-block;margin-left:4px;padding:1px 4px;border-radius:4px;border:1px solid #2a3f30;font-size:8px;font-weight:800;text-transform:uppercase;vertical-align:1px;color:#aec6a3;background:#16241a}
  .htag.kol{color:#fbbf24;border-color:rgba(251,191,36,.4);background:rgba(251,191,36,.1)}
  .htag.smart{color:#bff45f;border-color:rgba(163,230,53,.4);background:rgba(163,230,53,.1)}
  .htag.bad{color:#ff7a7a;border-color:rgba(255,122,122,.4);background:rgba(255,122,122,.1)}
  .hsub{color:#9cb490;font-size:10px;margin-top:1px}
  .hval{flex:0 0 auto;text-align:right;font-size:10.5px}
  .hval .p{font-weight:800}
  .up2{color:#59e08a}.dn2{color:#ff7a7a}
  .gsrc{margin:2px 14px 10px;text-align:right;font-size:8.5px;color:#83a077}
  .pager{display:flex;align-items:center;justify-content:center;gap:12px;margin:8px 14px 4px}
  .pager button{border:1px solid #1e2f24;background:#111d15;color:#c3d4ba;font-weight:700;font-size:11px;
    padding:5px 12px;border-radius:8px;cursor:pointer;transition:.12s}
  .pager button:hover:not(:disabled){border-color:#31503a;color:#eafbe1}
  .pager button:disabled{opacity:.35;cursor:default}
  .pager span{font-size:10.5px;font-weight:700;color:#9cb490}
  .bubblebox{margin:0 14px 4px;border-radius:12px;overflow:hidden;border:1px solid #1e2f24;background:#0d1712}
  .bubbleframe{display:block;width:100%;height:420px;border:0}
  .seg button.on-buy{background:#a3e635;color:#0b140c;box-shadow:0 3px 12px -3px rgba(163,230,53,.55)}
  .seg button.on-sell{background:#ff7a7a;color:#160b0b;box-shadow:0 3px 12px -3px rgba(255,122,122,.5)}
  .seg button:disabled{opacity:.35;cursor:default}
  .bar{padding:0 14px 14px}
  .amts{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:9px}
  .amts.pcts{grid-template-columns:repeat(3,1fr)}
  .amt{padding:9px 0;border-radius:10px;background:#111d15;color:#c3d4ba;border:1px solid #1e2f24;font-weight:700;
    font-size:12.5px;cursor:pointer;transition:.12s}
  .amt:hover{border-color:#31503a;color:#eafbe1}
  .amt.on{background:rgba(163,230,53,.15);border-color:rgba(163,230,53,.5);color:#bff45f}
  .cinrow{position:relative;margin-bottom:9px}
  .cin{width:100%;padding:9px 42px 9px 11px;border-radius:10px;background:#111d15;border:1px solid #1e2f24;
    color:#eafbe1;font-weight:700;font-size:13px;font-family:inherit;outline:none;font-variant-numeric:tabular-nums}
  .cin:focus{border-color:rgba(163,230,53,.55)}
  .cin::placeholder{color:#83a077;font-weight:600}
  .cunit{position:absolute;right:11px;top:50%;transform:translateY(-50%);font-size:11px;font-weight:800;color:#9cb490}
  .go{width:100%;padding:13px;border:0;border-radius:13px;font-weight:800;font-size:14.5px;cursor:pointer;transition:.15s}
  .go.buy{background:linear-gradient(180deg,#b6f24a,#96d92e);color:#0b140c;box-shadow:0 10px 24px -10px rgba(163,230,53,.65)}
  .go.sell{background:linear-gradient(180deg,#ff8a8a,#f76b6b);color:#160b0b;box-shadow:0 10px 24px -10px rgba(255,122,122,.55)}
  .go:hover{filter:brightness(1.06)}
  .go:active,.amt:active,.seg button:active{transform:scale(.98)}
  .go:disabled{opacity:.5;cursor:default;box-shadow:none;filter:none}
  .go.locked{background:#16241a;color:#eafbe1;border:1px solid #2a3f30;box-shadow:none}
  .note{padding:12px 14px;font-size:12.5px;color:#bdd3b2;text-align:center;line-height:1.45}
  .ok{color:#bff45f} .err{color:#ff7a7a} .u{text-decoration:underline}
  .foot{display:flex;justify-content:space-between;align-items:center;padding:9px 14px;border-top:1px solid #172319;
    font-weight:700;font-size:11px;color:#9cb490;background:rgba(0,0,0,.18)}
  .foot a{color:#bff45f;text-decoration:none;cursor:pointer}
  .foot a:hover{text-decoration:underline}
  .spin{display:inline-block;width:13px;height:13px;border:2px solid currentColor;border-right-color:transparent;
    border-radius:50%;animation:sp .7s linear infinite;vertical-align:-2px;margin-right:6px}
  @keyframes sp{to{transform:rotate(360deg)}}
`;function pt(t,e,o="Trade on HoodX"){const n=document.createElement("div");n.setAttribute(It,""),n.style.cssText="all:initial;display:block;",["click","pointerdown","mousedown","mouseup","keydown"].forEach(s=>n.addEventListener(s,l=>l.stopPropagation()));const c=n.attachShadow({mode:"open"}),g=document.createElement("style");g.textContent=Zt,c.appendChild(g);const r=document.createElement("div");c.appendChild(r),e.insertAdjacentElement("afterend",n);const u=document.createElement("button");u.className="pill",u.innerHTML=`${kt}<span>${o}</span>`,r.appendChild(u);let d=null;u.addEventListener("click",()=>{if(d){d.remove(),d=null,u.querySelector("span").textContent=o;return}d=document.createElement("div"),d.className="panel",r.appendChild(d),u.querySelector("span").textContent="Hide",Jt(t,d)})}function Jt(t,e){let o=null,n=null,c=null,g=null,r="buy",u="0.05",d=100,s="loading",l="",h="",M=null,T=!1,x=null,B=!1,y="trade",E="1H",O=!1;const X={};let R=!0,b,F=null,C="holders",H="",L=0;const z={},I={},U={},A=document.createElement("div");e.appendChild(A);function K(p=!1){const $=C+":"+H;if(p&&(delete z[$],delete U[$]),z[$]!==void 0||I[$])return;I[$]=!0,w({type:"STRIX_GMGN",what:"holders",ca:t,tab:C,orderBy:C==="traders"?"profit":"amount_percentage",tag:H||void 0}).then(k=>{I[$]=!1,k?.noKey?(R=!1,z[$]=null):k?.error?(z[$]=null,U[$]=String(k.error)):z[$]=Gt(k?.data),y==="holders"&&i()})}function nt(){x&&(y="chart",bt(),i())}function bt(){!x||X[E]!==void 0||O||(O=!0,w({type:"STRIX_CANDLES",pool:x,ca:t,tf:E}).then(p=>{X[E]=Array.isArray(p?.candles)&&p.candles.length?p.candles:null,O=!1,y==="chart"&&i()}))}const i=()=>{const p=Number(c?.amount||0);if(s==="loading"){A.innerHTML=`<div class="note"><span class="spin"></span>Loading ${st(t)}…</div>`;return}if(s==="notfound"){A.innerHTML='<div class="note">Not a tradable Robinhood Chain token.</div>';return}const $=!!o?.isStock,P=Number(o?.priceChange24h),k=isFinite(P)?`<div class="chg ${P>=0?"up":"dn"}">${P>=0?"+":""}${P.toFixed(2)}%</div>`:"",Ct=g?`<img class="logo" src="${g}"/>`:`<div class="logo">${kt}</div>`,_t=!n?.unlocked,Lt=$?`<div class="stockline">Tokenized <b>${S(o?.name||"")}</b> stock · trades via USDG, settles in ETH</div>`:`<div class="stats">
          <div class="stat"><span>Mcap</span><b>${rt(o?.mcap)}</b></div>
          <div class="stat"><span>Liq</span><b>${rt(o?.liquidityUsd)}</b></div>
          <div class="stat"><span>Vol 24h</span><b>${rt(o?.volume24h)}</b></div>
        </div>`,Ft=`<div class="seg">
      <button data-dir="buy" class="${r==="buy"?"on-buy":""}">Buy</button>
      <button data-dir="sell" class="${r==="sell"?"on-sell":""}" ${p<=0?"disabled":""}>Sell</button>
      ${x?`<button data-act="chart" class="chartbtn" title="Chart">${Xt}</button>`:""}
      ${R?`<button data-act="holders" class="chartbtn" title="Top holders & traders">${Kt}</button>`:""}
      <button data-act="bubbles" class="chartbtn" title="Bubble map">${jt}</button>
    </div>`,ut=qt(F),Mt=ut.length?`<div class="socials">${ut.map(a=>`<a href="${S(a.url)}" target="_blank" rel="noreferrer">${a.label}</a>`).join("")}</div>`:"";let j="";if(!R)j="";else if(b===void 0)j=`<div class="secbar na">${it}<span>Checking safety…</span></div>`;else if(b===null)j="";else{const{verdict:a}=ht(b);j=`<div class="secbar ${a}" data-act="safety">${it}<span>Safety: ${mt[a]}</span><i>details ›</i></div>`}const At=p>0?`<div class="hold">Holding <b>${Ot(p)} ${S(o?.symbol||"")}</b>${o?.priceUsd?` · ${dt(p*o.priceUsd)}`:""}</div>`:"";let G="";if(s==="done")G=`<div class="note ok">Done ✓ <a class="ok u" href="https://robinhoodchain.blockscout.com/tx/${h}" target="_blank">view tx</a></div>
        <div class="bar"><button class="go buy" data-act="again">Trade again</button></div>`;else if(_t)G='<div class="bar"><button class="go locked" data-act="unlock">Unlock HoodX to trade</button></div>';else if(r==="buy"){const a=Ut.map(_=>`<button class="amt ${_===u?"on":""}" data-amt="${_}">${_}</button>`).join(""),f=s==="busy"?`<span class="spin"></span>${S(l||"Buying…")}`:`Buy ${u||"0"} ETH`;G=`<div class="bar"><div class="amts">${a}</div><div class="cinrow"><input class="cin" data-cbuy inputmode="decimal" value="${S(u)}" placeholder="Custom amount"/><span class="cunit">ETH</span></div><button class="go buy" data-act="buy" ${s==="busy"||!(Number(u)>0)?"disabled":""}>${f}</button>${s==="error"?`<div class="note err">${S(l)}</div>`:""}</div>`}else{const a=Pt.map(_=>`<button class="amt ${_===d?"on":""}" data-pct="${_}">${_}%</button>`).join(""),f=s==="busy"?`<span class="spin"></span>${S(l||"Selling…")}`:`Sell ${d}% ${S(o?.symbol||"")}`;G=`<div class="bar"><div class="amts pcts">${a}</div><div class="cinrow"><input class="cin" data-csell inputmode="numeric" value="${d}" placeholder="Custom percent"/><span class="cunit">%</span></div><button class="go sell" data-act="sell" ${s==="busy"||p<=0||d<=0?"disabled":""}>${f}</button>${s==="error"?`<div class="note err">${S(l)}</div>`:""}</div>`}const Y=`
      <div class="head">${Ct}
        <div class="hd">
          <div class="symrow"><span class="sym">${S(o?.symbol||"TOKEN")}</span><span class="badge${$?" stk":""}">${$?"STOCK":S(o?.venue||"?")}</span></div>
          <div class="name">${S(o?.name||st(t))}</div>
          <div class="carow" data-act="copyca" title="Copy contract address">${st(t)} ${B?"<b>copied ✓</b>":"⧉"}</div>
        </div>
        <div class="price"><div class="pval"><span class="live"></span>${dt(o?.priceUsd)}</div>${k}</div>
      </div>`,q=`<div class="foot"><span>${n?.unlocked?`${S(n.label||"Wallet")} · ${Number(n.eth).toFixed(4)} ETH`:"HoodX · locked"}</span><a data-act="open">Open wallet ↗</a></div>`;if(y==="chart"){const a=X[E];let f="";if(a&&a.length>1){const N=(a[a.length-1][4]/a[0][1]-1)*100;f=`<span class="tfchg ${N>=0?"up":"dn"}">${N>=0?"+":""}${N.toFixed(2)}%</span>`}const _=`<div class="tfrow">${["15m","1H","4H","1D"].map(N=>`<button class="tfbtn ${N===E?"on":""}" data-tf="${N}">${N}</button>`).join("")}${f}</div>`,D=O||a===void 0?'<div class="chartbox"><div class="note"><span class="spin"></span>Loading chart…</div></div>':a?`<div class="chartbox">${Vt(a,E)}</div>`:'<div class="chartbox"><div class="note">No chart data for this token yet.</div></div>';A.innerHTML=`${Y}${_}${D}
        <div class="bar"><button class="go locked" data-act="back">← Back to trading</button></div>${q}`}else if(y==="safety"){let a;if(b==null)a='<div class="note">Safety data unavailable for this token.</div>';else{const{checks:f,verdict:_}=ht(b);a=`<div class="secbar ${_}" style="cursor:default">${it}<span>Safety: ${mt[_]}</span></div>
          <div class="secgrid">${f.map(D=>`<div class="seccell"><span>${D.label}</span><b class="${D.level}">${S(D.value)}</b></div>`).join("")}</div>`}A.innerHTML=`${Y}${a}
        <div class="bar"><button class="go locked" data-act="back">← Back to trading</button></div>${q}`}else if(y==="holders"){const a=C+":"+H,f=z[a],_=`<div class="tabs2">
        <button data-htab="holders" class="${C==="holders"?"on":""}">Holders</button>
        <button data-htab="traders" class="${C==="traders"?"on":""}">Traders</button>
      </div>
      <div class="chips">
        <button class="chip2 ${H===""?"on":""}" data-htag="">All</button>
        <button class="chip2 ${H==="renowned"?"on":""}" data-htag="renowned">KOLs</button>
        <button class="chip2 ${H==="smart_degen"?"on":""}" data-htag="smart_degen">Smart $</button>
      </div>`;let D;if(I[a]||f===void 0)D=`<div class="note"><span class="spin"></span>Loading ${C}…</div>`;else if(!f||!f.length)D=`<div class="note">${U[a]?`Couldn't load: ${S(U[a])}`:H?"None found in the top 100.":"No holder data for this token yet."}<br/><br/><button class="amt" data-act="hretry" style="padding:7px 18px">Retry</button></div>`;else{const N=f.filter(Q=>{const et=ct(Q);return et.includes("kol")||et.includes("renowned")}).length,ft=f.filter(Q=>ct(Q).includes("smart_degen")).length,Nt=!H&&(N||ft)?`<div class="kolline">Top ${f.length}: <b>${N} KOL${N===1?"":"s"}</b> · <span style="color:#bff45f">${ft} smart money</span></div>`:"",Z=5,J=Math.max(1,Math.ceil(f.length/Z));L>=J&&(L=J-1);const Ht=f.slice(L*Z,L*Z+Z),Rt=J>1?`<div class="pager">
              <button data-hpage="prev" ${L===0?"disabled":""}>‹ Prev</button>
              <span>${L+1} / ${J}</span>
              <button data-hpage="next" ${L>=J-1?"disabled":""}>Next ›</button>
            </div>`:"";D=Nt+Ht.map((Q,et)=>Wt(Q,L*Z+et+1)).join("")+Rt+`<div class="gsrc">${f.length} wallets · ${C==="traders"?"by profit":"by holdings"}</div>`}A.innerHTML=`${Y}${_}${D}
        <div class="bar" style="margin-top:10px"><button class="go locked" data-act="back">← Back to trading</button></div>${q}`}else if(y==="bubbles"){const a=chrome.runtime.getURL(`bubble.html?ca=${encodeURIComponent(t)}`);A.innerHTML=`${Y}
        <div class="bubblebox"><iframe class="bubbleframe" src="${a}" allow="clipboard-write"></iframe></div>
        <div class="gsrc">holder bubble map</div>
        <div class="bar"><button class="go locked" data-act="back">← Back to trading</button></div>${q}`}else A.innerHTML=`${Y}${Lt}${Mt}${j}${At}${Ft}${G}${q}`;const m=(a,f)=>A.querySelectorAll(a).forEach(_=>_.addEventListener("click",()=>f(_)));m("[data-dir]",a=>{r=a.dataset.dir,s==="error"&&(s="ready"),i()}),m("[data-amt]",a=>{u=a.dataset.amt,s==="error"&&(s="ready"),i()}),m("[data-pct]",a=>{d=Number(a.dataset.pct),s==="error"&&(s="ready"),i()}),m('[data-act="buy"]',Tt),m('[data-act="sell"]',Et),m('[data-act="chart"]',nt),m("[data-tf]",a=>{E=a.dataset.tf,bt(),i()}),m('[data-act="back"]',()=>{y="trade",i()}),m('[data-act="safety"]',()=>{y="safety",i()}),m('[data-act="holders"]',()=>{y="holders",K(),i()}),m('[data-act="bubbles"]',()=>{y="bubbles",i()}),m("[data-htab]",a=>{C=a.dataset.htab,L=0,K(),i()}),m("[data-htag]",a=>{H=a.dataset.htag||"",L=0,K(),i()}),m("[data-hpage]",a=>{L+=a.dataset.hpage==="next"?1:-1,L<0&&(L=0),i()}),m('[data-act="hretry"]',()=>{K(!0),i()}),m('[data-act="again"]',()=>{s="ready",h="",tt(),i()}),m('[data-act="copyca"]',()=>{navigator.clipboard?.writeText(t).then(()=>{B=!0,i(),setTimeout(()=>{B=!1,e.isConnected&&s!=="busy"&&!T&&i()},1500)})}),m('[data-act="unlock"]',()=>w({type:"STRIX_OPEN"})),m('[data-act="open"]',()=>w({type:"STRIX_OPEN_TRADE",ca:t}));const W=e.querySelector("[data-cbuy]");W&&(W.addEventListener("focus",()=>{T=!0}),W.addEventListener("blur",()=>{T=!1}),W.addEventListener("input",()=>{u=W.value.replace(/[^\d.]/g,"");const a=e.querySelector(".go.buy");a&&s!=="busy"&&(a.textContent=`Buy ${u||"0"} ETH`,a.disabled=!(Number(u)>0)),e.querySelectorAll("[data-amt]").forEach(f=>f.classList.toggle("on",f.dataset.amt===u))}));const V=e.querySelector("[data-csell]");V&&(V.addEventListener("focus",()=>{T=!0}),V.addEventListener("blur",()=>{T=!1}),V.addEventListener("input",()=>{d=Math.max(0,Math.min(100,Math.floor(Number(V.value)||0)));const a=e.querySelector(".go.sell");a&&s!=="busy"&&(a.textContent=`Sell ${d}% ${o?.symbol||""}`,a.disabled=p<=0||d<=0),e.querySelectorAll("[data-pct]").forEach(f=>f.classList.toggle("on",Number(f.dataset.pct)===d))}))};async function wt(){const[p,$,P]=await Promise.all([w({type:"STRIX_TOKEN",ca:t}),w({type:"STRIX_STATUS"}),w({type:"STRIX_PAIR",ca:t})]);if(n=$,x=P?.pair||null,!p?.info){s="notfound",i();return}o=p.info,s="ready",i(),w({type:"STRIX_GMGN",what:"security",ca:t}).then(k=>{k?.noKey?(R=!1,b=null):b=k?.error?null:k?.data??null,(y==="trade"||y==="safety")&&i()}),w({type:"STRIX_GMGN",what:"info",ca:t}).then(k=>{k?.noKey?R=!1:!k?.error&&k?.data&&(F=k.data,y==="trade"&&i())}),o.logo&&w({type:"STRIX_IMAGE",url:o.logo}).then(k=>{k?.data&&(g=k.data,i())}),tt(),M=setInterval(St,2e4)}async function tt(){c=await w({type:"STRIX_HOLDING",ca:t}),i()}async function St(){if(!e.isConnected){clearInterval(M);return}const[p,$]=await Promise.all([w({type:"STRIX_TOKEN",ca:t}),w({type:"STRIX_STATUS"})]);p?.info&&(o=p.info),n=$,s!=="busy"&&!T&&y!=="bubbles"&&i()}async function Tt(){s="busy",l="Confirming…",i();const p=await w({type:"STRIX_BUY",ca:t,amountEth:u});if(p?.error==="locked"){n={unlocked:!1},s="ready",i();return}if(p?.error){s="error",l=p.error,i();return}h=p.hash,s="done",i(),n=await w({type:"STRIX_STATUS"}),tt()}async function Et(){s="busy",l="Confirming…",i();const p=await w({type:"STRIX_SELL",ca:t,pct:d});if(p?.error==="locked"){n={unlocked:!1},s="ready",i();return}if(p?.error){s="error",l=p.error,i();return}h=p.hash,s="done",i(),n=await w({type:"STRIX_STATUS"}),tt()}i(),wt()}async function Qt(t,e){const o=await w({type:"STRIX_TICKER",symbol:t});o?.address&&e.isConnected&&pt(o.address,e,`Buy $${t}`)}function yt(){document.querySelectorAll(`[data-testid="tweetText"]:not([${xt}])`).forEach(t=>{t.setAttribute(xt,"1");const e=t.textContent||"";Array.from(new Set(e.match(zt)||[])).slice(0,2).forEach(r=>pt(r,t));const n=new Set;for(const r of e.matchAll(Dt))n.add(r[1].toUpperCase());const c=[],g=[];for(const r of n)gt[r]?c.push(r):r.length>=2&&!Bt.has(r)&&g.push(r);c.slice(0,2).forEach(r=>pt(gt[r],t,`Buy $${r}`)),g.slice(0,2).forEach(r=>Qt(r,t))})}function $t(){yt();let t;new MutationObserver(()=>{t&&clearTimeout(t),t=window.setTimeout(yt,400)}).observe(document.body,{childList:!0,subtree:!0})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",$t):$t();
})()
